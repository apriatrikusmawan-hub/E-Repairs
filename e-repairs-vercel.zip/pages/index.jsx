import Head from 'next/head'
import { useState, useRef, useEffect } from 'react'
import { Tool, Smartphone, Monitor, Tv, Wind, Star, MapPin, Clock, Mail, Phone } from 'lucide-react'

export default function Home() {
  const WA_LINK = `https://wa.me/6282285302057`

  const [name, setName] = useState('')
  const [deviceType, setDeviceType] = useState('HP / Tablet')
  const [issue, setIssue] = useState('')

  function openWhatsAppPrefilled() {
    const text = `Halo E-Repairs, saya ingin memperbaiki ${deviceType} dengan keluhan: ${issue}. Nama: ${name}. Mohon info lebih lanjut.`
    const href = `${WA_LINK}?text=${encodeURIComponent(text)}`
    window.open(href, '_blank')
  }

  // simple reveal-on-scroll
  const revealRefs = useRef([])
  revealRefs.current = []
  const addToRefs = el => {
    if (el && !revealRefs.current.includes(el)) revealRefs.current.push(el)
  }
  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('opacity-100','translate-y-0')
      })
    },{threshold: 0.15})
    revealRefs.current.forEach(r=>{
      r.classList.add('opacity-0','translate-y-6','transition','duration-700')
      obs.observe(r)
    })
    return ()=> obs.disconnect()
  },[])

  return (
    <>
      <Head>
        <title>E-Repairs — Jasa Service Elektronik di Medan</title>
        <meta name="description" content="E-Repairs: Perbaikan HP, laptop, TV, AC, kulkas, dan perangkat rumah tangga. Layanan antar jemput & konsultasi WhatsApp." />
        <meta name="keywords" content="jasa service elektronik, repair HP dan laptop, E-Repairs Indonesia" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.svg" />
      </Head>

      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 font-inter text-slate-800">
        <header className="bg-white shadow-sm sticky top-0 z-30">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#0ea5ff] to-[#0b69ff] flex items-center justify-center text-white font-bold">ER</div>
                  <div>
                    <div className="font-semibold text-lg">E-Repairs</div>
                    <div className="text-xs text-slate-500">Perbaikan Elektronik Profesional</div>
                  </div>
                </div>
              </div>

              <nav className="hidden md:flex items-center gap-6 text-sm">
                <a href="#home" className="hover:text-[#0b69ff]">Beranda</a>
                <a href="#services" className="hover:text-[#0b69ff]">Layanan</a>
                <a href="#about" className="hover:text-[#0b69ff]">Tentang Kami</a>
                <a href="#testimonials" className="hover:text-[#0b69ff]">Testimoni</a>
                <a href="#contact" className="hover:text-[#0b69ff]">Kontak</a>
              </nav>

              <div className="flex items-center gap-3">
                <a href={WA_LINK} target="_blank" rel="noreferrer" className="hidden sm:inline-flex items-center gap-2 bg-[#0b69ff] text-white px-4 py-2 rounded-2xl shadow hover:brightness-90 transition">
                  <Phone size={16} /> Pesan via WhatsApp
                </a>
              </div>
            </div>
          </div>
        </header>

        <main id="home" className="py-12">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <section className="py-6">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-tight">Solusi Cepat untuk Semua Masalah Elektronik Anda</h1>
              <p className="mt-4 text-slate-600 text-lg">Perbaikan profesional untuk HP, laptop, dan perangkat rumah tangga. Layanan antar jemput & garansi hingga 3 bulan.</p>

              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={() => window.open(`${WA_LINK}?text=${encodeURIComponent('Halo E-Repairs, saya ingin memesan layanan.')}`, '_blank')} className="bg-[#0b69ff] text-white px-6 py-3 rounded-xl shadow hover:brightness-95 transition">
                  Pesan Sekarang
                </button>
                <a href="#services" className="px-4 py-3 rounded-xl border border-slate-200 text-slate-700 hover:shadow">Lihat Layanan</a>
              </div>

              <ul className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-600">
                <li className="flex items-center gap-2"><Star size={16} className="text-yellow-400"/> Garansi sampai 3 bulan</li>
                <li className="flex items-center gap-2"><Clock size={16} className="text-slate-400"/> Layanan 08.00 - 22.00 WIB</li>
                <li className="flex items-center gap-2"><MapPin size={16} className="text-red-400"/> Jl. Pembangunan 1 No 6, Medan Timur</li>
                <li className="flex items-center gap-2"><Mail size={16} className="text-slate-400"/> erepairs@gmail.com</li>
              </ul>
            </section>

            <aside className="flex justify-center md:justify-end">
              <div className="bg-white p-6 rounded-2xl shadow-xl w-full max-w-md">
                <img src="/technician-illustration.svg" alt="Teknisi E-Repairs" className="w-full h-56 object-contain"/>
                <div className="mt-4 text-center text-sm text-slate-600">Teknisi bersertifikat — peralatan & suku cadang asli bila tersedia</div>
              </div>
            </aside>
          </div>
        </main>

        <section id="services" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-2xl font-bold mb-6">Layanan Kami</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Smartphone size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">HP & Tablet</h3>
                  <p className="text-sm text-slate-600">Perbaikan layar, penggantian baterai, kerusakan software. Estimasi mulai dari Rp10.000.</p>
                </div>
              </div>
            </article>

            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Tool size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">Laptop & PC</h3>
                  <p className="text-sm text-slate-600">Servis hardware, update OS, perbaikan motherboard. Estimasi mulai dari Rp50.000.</p>
                </div>
              </div>
            </article>

            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Monitor size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">TV & Audio</h3>
                  <p className="text-sm text-slate-600">Servis panel, tuner, speaker. Estimasi mulai dari Rp75.000.</p>
                </div>
              </div>
            </article>

            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Wind size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">AC & Kulkas</h3>
                  <p className="text-sm text-slate-600">Isi freon, kompresor, perbaikan kelistrikan. Estimasi mulai dari Rp100.000.</p>
                </div>
              </div>
            </article>

            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Tool size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">Mesin Cuci & Perangkat Rumah</h3>
                  <p className="text-sm text-slate-600">Perbaikan motor, pompa, kelistrikan. Estimasi mulai dari Rp80.000.</p>
                </div>
              </div>
            </article>

            <article ref={addToRefs} className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <Smartphone size={34} className="text-[#0b69ff]" />
                <div>
                  <h3 className="font-semibold">Konsultasi & Diagnosa via WhatsApp</h3>
                  <p className="text-sm text-slate-600">Konsultasi cepat dan rekomendasi biaya awal. Gratis lewat WhatsApp.</p>
                </div>
              </div>
            </article>
          </div>

          <div className="mt-8 text-sm text-slate-600">*Estimasi harga dasar — harga akhir ditentukan setelah diagnosa teknisi.</div>
        </section>

        <section id="about" className="bg-white/60 py-12">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-bold">Tentang E-Repairs</h2>
              <p className="mt-4 text-slate-600">E-Repairs berdiri untuk menyediakan layanan perbaikan elektronik yang cepat, transparan, dan profesional. Tim teknisi kami berpengalaman di berbagai merek dan model, menggunakan suku cadang berkualitas dan memberikan garansi sampai 3 bulan untuk perbaikan tertentu.</p>

              <ul className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                <li className="flex flex-col items-start gap-2">
                  <div className="p-3 bg-slate-100 rounded-lg"><Star size={18} className="text-yellow-400"/></div>
                  <div className="font-semibold">Garansi</div>
                  <div className="text-slate-500">Garansi sampai 3 bulan</div>
                </li>
                <li className="flex flex-col items-start gap-2">
                  <div className="p-3 bg-slate-100 rounded-lg"><Clock size={18} /></div>
                  <div className="font-semibold">Cepat</div>
                  <div className="text-slate-500">Estimasi perbaikan cepat & layanan antar jemput</div>
                </li>
                <li className="flex flex-col items-start gap-2">
                  <div className="p-3 bg-slate-100 rounded-lg"><Tool size={18} /></div>
                  <div className="font-semibold">Transparan</div>
                  <div className="text-slate-500">Harga terbuka & laporan kerusakan</div>
                </li>
              </ul>
            </div>

            <div className="p-6 rounded-2xl shadow bg-white">
              <h3 className="font-semibold">Daftar Harga (Dasar)</h3>
              <ul className="mt-4 divide-y">
                <li className="py-3 flex justify-between"><span>Diagnosa</span><span>Rp10.000</span></li>
                <li className="py-3 flex justify-between"><span>Ganti Baterai HP</span><span>Rp75.000</span></li>
                <li className="py-3 flex justify-between"><span>Ganti Layar HP</span><span>Rp200.000</span></li>
                <li className="py-3 flex justify-between"><span>Servis Laptop</span><span>Rp150.000</span></li>
                <li className="py-3 flex justify-between"><span>Servis AC (Dasar)</span><span>Rp100.000</span></li>
              </ul>
              <div className="mt-3 text-xs text-slate-500">*Harga perkiraan awal — dapat berubah setelah diagnosa.</div>
            </div>
          </div>
        </section>

        <section id="testimonials" className="py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold mb-6">Testimoni Pelanggan</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                {name: 'Rina S.', text: 'Layanan cepat dan teknisinya ramah. HP saya kembali normal!', rating: 5},
                {name: 'Budi H.', text: 'Harga transparan dan garansi 1 bulan membantu.', rating: 4},
                {name: 'Sari P.', text: 'Antar jemput memudahkan pekerjaan saya — recommended!', rating: 5}
              ].map((t, i) => (
                <blockquote key={i} ref={addToRefs} className="p-4 bg-white rounded-2xl shadow">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-[#cfe9ff] flex items-center justify-center font-semibold">{t.name.split(' ')[0][0]}</div>
                    <div>
                      <div className="font-semibold">{t.name}</div>
                      <div className="text-yellow-400 flex items-center">
                        {Array.from({length: t.rating}).map((_, idx) => <Star key={idx} size={14} />)}
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-slate-600">{t.text}</p>
                </blockquote>
              ))}
            </div>
          </div>
        </section>

        <section id="quick-order" className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-xl font-bold mb-4">Formulir Pemesanan Cepat</h2>
          <div className="p-6 bg-white rounded-2xl shadow">
            <label className="block text-sm">Nama</label>
            <input value={name} onChange={e => setName(e.target.value)} className="mt-2 w-full rounded-md border px-3 py-2" placeholder="Nama lengkap" />

            <label className="block text-sm mt-3">Jenis Perangkat</label>
            <select value={deviceType} onChange={e => setDeviceType(e.target.value)} className="mt-2 w-full rounded-md border px-3 py-2">
              <option>HP / Tablet</option>
              <option>Laptop / PC</option>
              <option>TV / Audio</option>
              <option>AC / Kulkas</option>
              <option>Mesin Cuci / Rumah</option>
            </select>

            <label className="block text-sm mt-3">Keluhan Singkat</label>
            <textarea value={issue} onChange={e => setIssue(e.target.value)} className="mt-2 w-full rounded-md border px-3 py-2" rows={3} placeholder="Contoh: layar pecah / tidak menyala / bunyi aneh"></textarea>

            <div className="mt-4 flex gap-3">
              <button onClick={openWhatsAppPrefilled} className="bg-[#0b69ff] text-white px-5 py-2 rounded-xl">Kirim ke WhatsApp</button>
              <button onClick={() => { setName(''); setIssue(''); setDeviceType('HP / Tablet') }} className="px-4 py-2 rounded-xl border">Reset</button>
            </div>
          </div>
        </section>

        <footer id="contact" className="bg-[#0b69ff] text-white mt-8">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-lg">E-Repairs</h3>
              <p className="mt-2 text-sm">Jl. Pembangunan 1 No 6, Medan Timur, Kota Medan</p>
              <p className="mt-1 text-sm">Jam operasional: 08.00 WIB - 22.00 WIB</p>
            </div>

            <div>
              <h4 className="font-semibold">Kontak</h4>
              <p className="mt-2 text-sm flex items-center gap-2"><Phone size={14}/> <a href="https://wa.me/6282285302057" target="_blank" rel="noreferrer">0822-8530-2057</a></p>
              <p className="mt-1 text-sm flex items-center gap-2"><Mail size={14}/> erepairs@gmail.com</p>
            </div>

            <div>
              <h4 className="font-semibold">Ikuti Kami</h4>
              <p className="mt-2 text-sm">(Tambahkan link sosial media jika ada)</p>
              <div className="mt-3">
                <a href={WA_LINK} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-white/10 px-3 py-2 rounded">Pesan via WhatsApp</a>
              </div>
            </div>
          </div>

          <div className="border-t border-white/20 text-center py-4 text-sm">© 2025 E-Repairs. Semua hak cipta dilindungi.</div>
        </footer>
      </div>
    </>
  )
}

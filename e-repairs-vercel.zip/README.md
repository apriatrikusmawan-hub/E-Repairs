# E-Repairs — Next.js + Tailwind (Ready for Vercel)

This package is a ready-to-deploy Next.js project for **E-Repairs**.

## How to deploy
1. Download the ZIP and unzip.
2. (Optional) Edit `pages/index.jsx` or other files to customize.
3. Create a Git repository OR directly upload the ZIP to Vercel:
   - Go to https://vercel.com/new → Import Project → **Upload** → Select the unzipped folder.
4. Click **Deploy**. Your site will be available at `https://<your-name>.vercel.app`.

## Notes
- WhatsApp link uses: `https://wa.me/6282285302057`
- Tailwind & lucide-react are included. If you modify dependencies, run `npm install`.
